<?php
    include('../modelos/conexion.php');

    
    $N1= $_POST['Nombre1'];
    $a= $_POST['area'];

 

    $query="INSERT INTO `vendedores`( `Nombre`, `Area`)
    VALUES ('$N1','$a')";

    $res=$conexion->query($query);
    if($res){
        //Redireccionando a la lista
        header("location:../vistas/listaVendedores.php");
    }else{

        echo"no se guardo";
    }

