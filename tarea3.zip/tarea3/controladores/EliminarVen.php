<?php
include('../modelos/conexion.php');

$ide=$_REQUEST['ide'];

$query="DELETE FROM `vendedores`  WHERE  id_Vendedores='$ide'";

$res=$conexion->query($query);
if($res){
// redireccionando la vista.
     header("location:../vistas/listaVendedores.php");
}else{

    echo"No se pudo eliminar";
}

?>