<?php
include('../modelos/conexion.php');

   $idee=$_REQUEST['ide'];
    $p= $_POST['producto'];
    $c= $_POST['cantidad'];
    $pr= $_POST['precio_unitario'];
    $NV= $_POST['dVentas'];

$query="UPDATE `detalle_venta` 
SET 
`id_ventas`=' $NV',
`Producto`='$p',
`Cantidad`='$c',
`Precio_Unitario`='$pr'
 WHERE id_Detalle='$idee'";

$res=$conexion->query($query);
if($res){
// redireccionando la vista.
     header("location:../vistas/listaDetalle.php");
}else{

    echo"no se actualizo";
}

?>