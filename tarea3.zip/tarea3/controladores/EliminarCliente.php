<?php
include('../modelos/conexion.php');

$idE=$_REQUEST['ide'];

$query="DELETE FROM `clientes`  WHERE  id_cliente='$idE'";

$res=$conexion->query($query);
if($res){
// redireccionando la vista.
     header("location:../vistas/ListaCliente.php");
}else{

    echo"No se pudo eliminar";
}

?>