<?php
    include('../modelos/conexion.php');

    
    $fe= $_POST['fecha1'];
    $ven= $_POST['vendedores'];
    $cli= $_POST['clientes'];


 

    $query="INSERT INTO `ventas`(  `Fecha`,`id_Vendedores`, `id_cliente`)
    VALUES ('$fe','$ven','$cli')";

    $res=$conexion->query($query);
    if($res){
        //Redireccionando a la lista
        header("location:../vistas/ListaVentas.php");
    }else{

        echo"no se guardo";
    }

