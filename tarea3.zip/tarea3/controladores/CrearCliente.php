<?php
    include('../modelos/conexion.php');

    
    $N= $_POST['Nombre'];
    $E= $_POST['email'];

 

    $query="INSERT INTO `clientes`( `Nombre`, `Email`)
    VALUES ('$N','$E')";

    $res=$conexion->query($query);
    if($res){
        //Redireccionando a la lista
        header("location:../vistas/ListaCliente.php");
    }else{

        echo"no se guardo";
    }

