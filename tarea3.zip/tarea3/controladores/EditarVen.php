<?php
include('../modelos/conexion.php');

    $ide=$_REQUEST['ide'];
    $fe= $_POST['fecha1'];
    $ven= $_POST['vendedores'];
    $cli= $_POST['clientes'];



$query="UPDATE `ventas`
 SET 
 `id_Vendedores`='[value-2]',
 `id_cliente`='[value-3]',
 `Fecha`='[value-4]'
  WHERE  id_Ventas=''";

$res=$conexion->query($query);
if($res){
// redireccionando la vista.
     header("location:../vistas/listaVendedores.php");
}else{

    echo"no se actualizo";
}

?>