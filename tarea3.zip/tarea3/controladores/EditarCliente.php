<?php
include('../modelos/conexion.php');

    $idE=$_REQUEST['ide'];
    $N= $_POST['Nombre'];
    $E= $_POST['email'];


$query="UPDATE `clientes` 
 SET 
 `Nombre`='$N',
 `Email`='$E' 
 WHERE id_cliente='$idE'";

$res=$conexion->query($query);
if($res){
// redireccionando la vista.
     header("location:../vistas/ListaCliente.php");
}else{

    echo"no se actualizo";
}

?>