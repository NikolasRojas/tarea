<?php
include('../modelos/conexion.php');

    $idi=$_REQUEST['ide'];
    $fe= $_POST['fecha1'];
    $ven= $_POST['vendedores'];
    $cli= $_POST['clientes'];



$query="UPDATE `ventas`
 SET 
 `id_Vendedores`='$ven',
 `id_cliente`='$cli',
 `Fecha`='$fe'
  WHERE  id_Ventas='$idi'";

$res=$conexion->query($query);
if($res){
// redireccionando la vista.
     header("location:../vistas/ListaVentas.php");
}else{

    echo"no se actualizo";
}

?>