<?php
include('../modelos/conexion.php');

$idi=$_REQUEST['ide'];

$query="DELETE FROM `ventas`  WHERE  id_Ventas='$idi'";

$res=$conexion->query($query);
if($res){
// redireccionando la vista.
     header("location:../vistas/ListaVentas.php");
}else{

    echo"No se pudo eliminar";
}

?>