<?php
    include('../modelos/conexion.php');

    
    $p= $_POST['producto'];
    $c= $_POST['cantidad'];
    $pr= $_POST['precio_unitario'];
    $NV= $_POST['dVentas'];

 

    $query="INSERT INTO `detalle_venta`( `Producto`, `Cantidad`, `Precio_Unitario`,`id_ventas`) 
    VALUES ('$p','$c','$pr','$NV')";

    $res=$conexion->query($query);
    if($res){
        //Redireccionando a la lista
        header("location:../vistas/listaDetalle.php");
    }else{

        echo"no se guardo";
    }

