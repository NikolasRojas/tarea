<?php
include('../modelos/conexion.php');

$idee=$_REQUEST['ide'];

$query="DELETE FROM `detalle_venta`  WHERE id_Detalle='$idee'";

$res=$conexion->query($query);
if($res){
// redireccionando la vista.
     header("location:../vistas/listaDetalle.php");
}else{

    echo"No se pudo eliminar";
}

?>
