<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista del cliente</title>
</head>
<body>
    <?php 
      include "menu.php"; 
    ?>

    <div class="container">
        <h3>Lista del cliente</h3>
      <div class="row">
        
        <table class="table">

            <thead>

            
                <tr>
                    <th>Idss</th>
                    <th>Nombre</th>
                    <th>Email</th>
                  
                   
                </tr>
            </thead>

            <tbody>
                <?php
                    include('../modelos/conexion.php');

                    $query ="SELECT `id_cliente`, `Nombre`, `Email` FROM `clientes`";
                    $res =$conexion->query($query);

                    while($row=$res->fetch_assoc())
                    {
                        ?>
                        <tr>
                            <td><?php echo $row['id_cliente']; ?></td>
                            <td><?php echo $row['Nombre']; ?></td>
                            <td><?php echo $row['Email']; ?></td>
                           
                 <td class="text-center">
                <a class="btn btn-success" href="../vistas/EditarClientes.php?ide=<?php echo $row['id_cliente'];?>" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Actualizar">
                <span class="fas fa-trash">Actualizar</span>
                </a>
            </td>
            <td class="text-center"> 
                <a class="btn btn-danger" href="../controladores/EliminarCliente.php?ide=<?php echo $row['id_cliente'];?>" 
                class="btn btn-xs btn-danger" data-toggle="tooltip" title="Eliminar">
                    <span class="fas fa-trash"> Eliminar</span>
                </a>
            </td>

                        </tr>
                    <?php
                    }
                ?>
                
            </tbody>
        </table>
      </div>
    </div>
</body>
</html>