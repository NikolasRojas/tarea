<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detallest</title>
</head>
<body>
<?php
    include "menu.php";
?>
<DIV class="container">
<div class="row">

<?php
        $idee=$_REQUEST['ide'];
            //llamar  a la conexion de base de datos
                include('../modelos/conexion.php');

                //consulta de query mostrar datos
                $query="SELECT * FROM `detalle_venta` WHERE id_Detalle='$idee'";
                //asegurar la conexion ennviando la consulta
                $res=$conexion->query($query);
                //recorer todas la columnas
               $row= $res->fetch_assoc()
            ?>


<form method="POST" action="../controladores/EditarVen.php?ide=<?php echo $row['id_Detalle'];?>" >
    <div class="form-group">
        <label for="">Producto</label>
        <input type="text" class="form-control" name="producto" required  value=" <?php echo $row['Producto']; ?>">
    </div>
    <div class="form-group">
        <label for="">Cantidad</label>
        <input type="text" class="form-control" name="cantidad" required  value=" <?php echo $row['Cantidad']; ?>">
    </div>
    <div class="form-group">
        <label for="">Precio unitario</label>
        <input type="text" class="form-control" name="precio_unitario" required value=" <?php echo $row['Precio_Unitario']; ?>">
    </div>

    <div class="form-group">
        <label for="">Seleccione un estudiante</label>
        <select class="form-select" name="idVentas" >

            <?php
            //llamar  a la conexion de base de datos
                include('../modelos/conexion.php');

                //consulta de query mostrar datos
                $query="SELECT `id_Ventas`, `id_Vendedores` FROM `ventas` ";
                //asegurar la conexion ennviando la consulta
                $res=$conexion->query($query);
                //recorer todas la columnas
                if($res->num_rows>0){
                        $combobit="";
                        //comparamos mientras existan los datos
                        while($row=$res->fetch_array(MYSQLI_ASSOC))
                        {
                            //almacer en una varia los campos
                            $combobit="<option value=".$row['id_Ventas'].">".$row['id_Vendedores']."</option>";
                            echo $combobit;

                        }

                }else
                {
                        echo "No hay ningun datos para mostrar";
                }
            ?>
         </select>
    </div>

    <br>
    <button class="btn btn-primary" name="add_producto">Guadar</button>
</form>


</div>

</DIV>

    
</body>
</html>