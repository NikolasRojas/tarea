<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    include "menu.php";
?>
<DIV class="container">
<div class="row">
<?php
        $idE=$_REQUEST['ide'];
            //llamar  a la conexion de base de datos
                include('../modelos/conexion.php');

                //consulta de query mostrar datos
                $query="SELECT * FROM `clientes` WHERE id_cliente='$idE'";
                //asegurar la conexion ennviando la consulta
                $res=$conexion->query($query);
                //recorer todas la columnas
               $row= $res->fetch_assoc()
            ?>


<form method="POST" action="../controladores/EditarCliente.php?ide=<?php echo $row['id_cliente'];?>" >
    <div class="form-group">
        <label for="">Nombre</label>
        <input type="text" class="form-control" name="Nombre" required value=" <?php echo $row['Nombre']; ?>">
    </div>
    <div class="form-group">
        <label for="">Email</label>
        <input type="text" class="form-control" name="email" required value="<?php echo $row['Email']; ?>" >
    </div>
  

    <br>
    <button class="btn btn-primary" name="add_producto">Guadar</button>
</form>







            </div>

</DIV>

    
</body>
</html>