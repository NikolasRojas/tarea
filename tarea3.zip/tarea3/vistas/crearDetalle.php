<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detallest</title>
</head>
<body>
<?php
    include "menu.php";
?>
<DIV class="container">
<div class="row">

<form method="POST" action="../controladores/crearDetalle.php" >
    <div class="form-group">
        <label for="">Producto</label>
        <input type="text" class="form-control" name="producto" required>
    </div>
    <div class="form-group">
        <label for="">Cantidad</label>
        <input type="text" class="form-control" name="cantidad" required>
    </div>
    <div class="form-group">
        <label for="">Precio unitario</label>
        <input type="text" class="form-control" name="precio_unitario" required>
    </div>

 <div class="form-group">
    <label for="">Seleccione una venta</label>
    <select class="form-select" name="dVentas" required>

        <?php
        include('../modelos/conexion.php');

        $query = "
            SELECT ventas.id_Ventas, vendedores.Nombre AS nombre_vendedor
            FROM ventas 
            INNER JOIN vendedores ON ventas.id_Vendedores = vendedores.id_Vendedores
        ";

        $res = $conexion->query($query);

        if ($res && $res->num_rows > 0) {
            while ($row = $res->fetch_assoc()) {
                // VERIFICACIÓN directa del contenido:
                // echo "<pre>"; print_r($row); echo "</pre>";
                
                echo "<option value='" . $row['id_Ventas'] . "'>" . $row['nombre_vendedor'] . "</option>";
            }
        } else {
            echo "<option>No hay ventas registradas</option>";
        }
        ?>
    </select>
</div>

    <br>
    <button class="btn btn-primary" name="add_producto">Guadar</button>
</form>


</div>

</DIV>

    
</body>
</html>