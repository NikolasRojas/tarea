<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista del Detalles</title>
</head>
<body>
    <?php 
      include "menu.php"; 
    ?>

    <div class="container">
        <h3>Lista del Detalles</h3>
      <div class="row">
        
        <table class="table">

            <thead>

            
                <tr>
                    <th>Idss</th>
                    <th>Ventas</th>
                    <th>Productos</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>

                  
                   
                </tr>
            </thead>

            <tbody>
                <?php
                    include('../modelos/conexion.php');

                    $query ="SELECT `id_Detalle`, `id_ventas`, `Producto`, `Cantidad`, `Precio_Unitario` FROM `detalle_venta` ";
                    $res =$conexion->query($query);

                    while($row=$res->fetch_assoc())
                    {
                        ?>
                        <tr>
                            <td><?php echo $row['id_Detalle']; ?></td>
                            <td><?php echo $row['id_ventas']; ?></td>
                            <td><?php echo $row['Producto']; ?></td>
                            <td><?php echo $row['Cantidad']; ?></td>
                            <td><?php echo $row['Precio_Unitario']; ?></td>
                           
                

                            <td class="text-center">
                <a class="btn btn-success" href="../vistas/EditarDeta.php?ide=<?php echo $row['id_Detalle'];?>" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Actualizar">
                <span class="fas fa-trash">Actualizar</span>
                </a>
            </td>
            <td class="text-center"> 
                <a class="btn btn-danger" href="../controladores/EliminarDeta.php?ide=<?php echo $row['id_Detalle'];?>" 
                class="btn btn-xs btn-danger" data-toggle="tooltip" title="Eliminar">
                    <span class="fas fa-trash"> Eliminar</span>
                </a>
            </td>
                        </tr>
                    <?php
                    }
                ?>
                
            </tbody>
        </table>
      </div>
    </div>
</body>
</html>