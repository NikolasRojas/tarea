<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cliente</title>
</head>
<body>
<?php
    include "menu.php";
?>
<DIV class="container">
<div class="row">

<form method="POST" action="../controladores/CrearCliente.php" >
    <div class="form-group">
        <label for="">Nombre</label>
        <input type="text" class="form-control" name="Nombre" required>
    </div>
    <div class="form-group">
        <label for="">Email</label>
        <input type="text" class="form-control" name="email" required>
    </div>
  

    <br>
    <button class="btn btn-primary" name="add_producto">Guadar</button>
</form>


</div>

</DIV>

    
</body>
</html>