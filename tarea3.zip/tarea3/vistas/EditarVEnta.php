<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ventas</title>
</head>
<body>
<?php
    include "menu.php";
?>
<DIV class="container">
<div class="row">


<?php
        $idi=$_REQUEST['ide'];
            //llamar  a la conexion de base de datos
                include('../modelos/conexion.php');

                //consulta de query mostrar datos
                $query="SELECT * FROM `ventas` WHERE id_Ventas='$idi'";
                //asegurar la conexion ennviando la consulta
                $res=$conexion->query($query);
                //recorer todas la columnas
               $row= $res->fetch_assoc()
            ?>



<form method="POST" action="../controladores/EditarVEnta.php?ide=<?php echo $row[' id_Ventas'];?>" >
    <div class="form-group">
        <label for="">Fecha</label>
        <input type="date" class="form-control" name="fecha1" required value=" <?php echo $row['fecha1']; ?>">
    </div>


    <div class="form-group">
        <label for="">Seleccione un vendedores</label>
        <select class="form-select" name="vendedores" id="">

            <?php
            //llamar  a la conexion de base de datos
                include('../modelos/conexion.php');

                //consulta de query mostrar datos
                $query="SELECT `id_Vendedores`, `Nombre`, FROM `vendedores` ";
                //asegurar la conexion ennviando la consulta
                $res=$conexion->query($query);
                //recorer todas la columnas
                if($res->num_rows>0){
                        $combobit="";
                        //comparamos mientras existan los datos
                        while($row=$res->fetch_array(MYSQLI_ASSOC))
                        {
                            //almacer en una varia los campos
                            $combobit="<option value=".$row['id_Vendedores'].">".$row['Nombre']."</option>";
                            echo $combobit;

                        }

                }else
                {
                        echo "No hay ningun datos para mostrar";
                }
            ?>
         </select>
    </div>
    
    <div class="form-group">
        <label for="">Seleccione un clientes</label>
        <select class="form-select" name="clientes" id="">

            <?php
            //llamar  a la conexion de base de datos
                include('../modelos/conexion.php');

                //consulta de query mostrar datos
                $query="SELECT `id_cliente`, `Nombre`,  FROM `clientes`";
                //asegurar la conexion ennviando la consulta
                $res=$conexion->query($query);
                //recorer todas la columnas
                if($res->num_rows>0){
                        $combobit="";
                        //comparamos mientras existan los datos
                        while($row=$res->fetch_array(MYSQLI_ASSOC))
                        {
                            //almacer en una varia los campos
                            $combobit="<option value=".$row['id_cliente'].">".$row['Nombre']."</option>";
                            echo $combobit;

                        }

                }else
                {
                        echo "No hay ningun datos para mostrar";
                }
            ?>
         </select>
    </div>

    <br>
    <button class="btn btn-primary" name="add_producto">Guadar</button>
</form>


</div>

</DIV>

    
</body>
</html>