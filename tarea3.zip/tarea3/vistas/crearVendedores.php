<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>vendedores</title>
</head>
<body>
<?php
    include "menu.php";
?>
<DIV class="container">
<div class="row">

<form method="POST" action="../controladores/CrearVendedores.php" >
    <div class="form-group">
        <label for="">Nombre</label>
        <input type="text" class="form-control" name="Nombre1" required>
    </div>
    <div class="form-group">
        <label for="">Area</label>
        <input type="text" class="form-control" name="area" required>
    </div>
   

    <br>
    <button class="btn btn-primary" name="add_producto">Guadar</button>
</form>


</div>

</DIV>

    
</body>
</html>