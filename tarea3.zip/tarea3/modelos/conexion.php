<?php

$conexion= mysqli_connect('localhost','root','','tareanueva') 
or die ('no existe la conexion');




?>